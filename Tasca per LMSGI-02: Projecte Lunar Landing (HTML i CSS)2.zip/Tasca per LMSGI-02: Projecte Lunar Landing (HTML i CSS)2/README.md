<h1>Criterios personales sobre la tarea</h1>

<h4><p>La confección y elaboración de esta tarea ha sido realizada con muchas pruebas para desarrollar facilidad y familiarizarme con este nuevo estilo.</p>
<p><h4> A pesar de encontrarme con muchas trabas a la hora de encontrar la forma exacta con la que realizar la tarea, creo que mi forma de crear la página con tablas para realizar las modificaciones dentro de ella no ha sido la más acertada, aún así, me gustaría que me confirmases para aprender más. No he cogido ninguna página como punto de referencia, únicamente ha sido fruto de muchas pruebas y búsquedas para orientarme.</p>
<p><h4>He podido observar, que existen errores al corregir el código con un validador, por lo tanto deduzco que no ha salido todo lo bien que pensaba, por favor, dame unas indicaciones básicas de como debría ser o para orientarme un poco más.
</p></h4>
<p><h4><center>Muchas gracias, Alberto Torres.</p></h4></center>